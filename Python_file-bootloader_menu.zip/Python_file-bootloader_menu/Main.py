import pygame
import os
import time
import sys
import subprocess

# Initialize the pygame module
pygame.init()

# Define simple variables like version and the folder where you want to store the scripts in.
program_version = "3.0.9 (custom)"
scripts_folder = "scripts"
pygame.display.set_caption("309's-python-GRUB-menu")
file_type = ('.py')

# Define screen variables
initial_size_x = 990
initial_size_y = 600
initial_size = initial_size_x, initial_size_y
window_surface = pygame.display.set_mode(initial_size)

# Define boot logo variables
image_name = "Boot_splash.png"
current_directory = os.path.dirname(os.path.realpath(__file__))
assets_directory = os.path.join(current_directory, "assets")
graphics_directory = os.path.join(assets_directory, "graphics")
image_path = os.path.join(graphics_directory, image_name)
image = pygame.image.load(image_path)
Bs_x = initial_size_x - 530
Bs_y = initial_size_y - 335

# Define color variables
white = (255, 255, 255)
black = (0, 0, 0)
default_window_color = black
border_color = (225, 225, 225)
text_color = (250, 250, 250)

# Define border variables
border_thickness = 2
border_x = initial_size_x - 100
border_y = initial_size_y - 200
initial_border_size = border_x, border_y

# Define text variables
font1name = "DejaVuSansMono.ttf"
font_path1 = os.path.join(assets_directory, "fonts", font1name)
font1 = pygame.font.Font(font_path1, 13)
text_title_gm = font1.render(f"309's-GRUB version {program_version}", False, text_color)
text_gm_foot1 = font1.render("Use the ↑ and ↓ keys to select which entry is highlighted.", False, text_color)
text_gm_foot2 = font1.render("Press enter to boot the selected File, 'e' to edit the commands", False, text_color)
text_gm_foot3 = font1.render("before booting or 'c' for a command-line", False, text_color)

python_files_directory = os.path.join(current_directory, scripts_folder)
Files_list = [file for file in os.listdir(python_files_directory) if file.endswith(file_type) and file != 'Main.py']


# Initialize variables
selected_index = 0
selector_height = len(Files_list) * 30
selector_y = (initial_size_y - selector_height) // 2

# Main code
time.sleep(1)
window_surface.blit(image, (Bs_x, Bs_y))
pygame.display.flip()
time.sleep(2.5)
window_surface.fill(default_window_color)
pygame.display.flip()
pygame.draw.rect(window_surface, border_color, pygame.Rect(50, 70, initial_border_size[0], initial_border_size[1]), border_thickness)
pygame.display.flip()
window_surface.blit(text_title_gm, (initial_size_x - 650, 30))
window_surface.blit(text_gm_foot1, (250, 480))
window_surface.blit(text_gm_foot2, (250, 500))
window_surface.blit(text_gm_foot3, (250, 520))
pygame.display.flip()

# Main loop
running = True
while running:
    if not Files_list:
        window_surface.fill(default_window_color)
        pygame.draw.rect(window_surface, border_color, pygame.Rect(50, 70, initial_border_size[0], initial_border_size[1]), border_thickness)
        window_surface.blit(text_title_gm, (initial_size_x - 650, 30))
        no_file_text = font1.render("No python file found!", True, text_color)
        window_surface.blit(no_file_text, (60, 75))
        pygame.display.flip()
    else:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    selected_index = (selected_index - 1) % len(Files_list)
                elif event.key == pygame.K_DOWN:
                    selected_index = (selected_index + 1) % len(Files_list)
                elif event.key == pygame.K_RETURN:
                    selected_file = os.path.join(python_files_directory, Files_list[selected_index])  # Full path to the selected script
                    print(f"Selected file: {selected_file}")
                    subprocess.Popen(["python", "-Xfrozen_modules=off", selected_file])  # Execute the selected file in a separate process
                    time.sleep(2)
                    pygame.quit()

        window_surface.fill(default_window_color)
        pygame.draw.rect(window_surface, border_color, pygame.Rect(50, 70, initial_border_size[0], initial_border_size[1]), border_thickness)
        window_surface.blit(text_title_gm, (initial_size_x - 650, 30))
        window_surface.blit(text_gm_foot1, (250, 480))
        window_surface.blit(text_gm_foot2, (250, 500))
        window_surface.blit(text_gm_foot3, (250, 520))

        # Render truncated or ellipsized file names within the specified borders
        for i, file in enumerate(Files_list):
            truncated_file = file if len(file) <= 25 else "..." + file[-22:]
            text = font1.render(truncated_file, True, text_color)
            text_pos = 50 + border_thickness, 90 + i * 20  # Adjusted text position to include the border
            if i == selected_index:
                pygame.draw.rect(window_surface, white, (text_pos[0] - 3, text_pos[1] - 3, text.get_width() + 20, text.get_height() + 10), 2)
            window_surface.blit(text, text_pos)

        pygame.display.flip()

pygame.quit()
sys.exit()
