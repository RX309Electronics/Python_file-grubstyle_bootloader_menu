This software is free and unlicensed but i would still like it and it would be kind of you if you put some credit of me the creator When you distribute the software to the internet, like making a video about it. I will be happy when you put either the link to my github or my project in the description or put "Made by: 309Electronics" in the description. I am just a hobbyist and would like to get a bit more attention from the general public so if you could, please credit me, it would help me a lot and would make my motivation not fade away. 

About The Creator 309Electronics: 309Electronics is a self educated electronics enthuisiast, thinkerer, engineer, reverse engineer, programmer, repair guy and project creator. I live in the Netherlands in Eindhoven in a small village called 'acht' I am a highschool student Who likes electronics and coding. i am pretty proud of my work! Please dont expect amazing quality or criticise some things i do or neat code because my motto is "If it works dont touch it" and i am just a hobbyist and not a profesional. Although i am open for any improvements or tips if you can provide them feel free to do so, i like to learn new ways and things. If there are any problems, bugs or you can provide tips please email me to 309Projectscustomerline@gmail.com (long email adres, i know!). Please know that apart from coding and doing the things i like, i also am still a student and have school 5 days in the week + homework to do so i might not always check the customer line/have time to do so. Please be patient and i will always react with a thank you mail or a "got it". I hope you like this project and feel free to scroll through my github page full of (dumb) projects. :)

How to use? 
To use this project follow the below instructions, have fun! 

Windows:
1. Download python from python.org and use the installer to install it onto your system. (if already installed skip to step 2)
2. Install pip by following the instructions on this page: https://pip.pypa.io/en/stable/installation/ (if pip is installed continue to step 3)
3. install the required modules by executing the batch file which will read requirements.txt file which contains the modules and uses pip to install it.
4. Execute the Main.py file 
5. Have fun!


Linux:
1. install everything by executing "sudo bash Install_requirements.sh" in the folder the file is in. Put in the password and it auto installs everything.
2. Execute the Main.py file by clicking on it or using the terminal, cd into the folder the script is in and using "python3 Main.py"
3. Have fun!
