#!/bin/bash

# Update package lists and upgrade installed packages
sudo apt update
sudo apt upgrade -y

# Install Python 3 and pip
sudo apt install -y python3 python3-pip

# Install Python packages from requirements.txt using pip
sudo pip3 install -r requirements.txt --break-system-packages

# Inform the user that installation is complete
echo "Installation complete. You can now use the application."

