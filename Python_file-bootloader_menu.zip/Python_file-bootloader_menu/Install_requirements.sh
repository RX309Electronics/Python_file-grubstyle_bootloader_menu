echo Installing all requirements, please wait...
echo Please put in your root password so the installer canb install python and the modules as a superuser.
sudo apt update && sudo apt upgrade -y
sudo apt-get install python3-full -y && sudo apt install python3-pip -y
pip3 install -r requirements.txt --break-system-packages
echo DONE!